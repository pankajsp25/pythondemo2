from django.contrib import admin
from . import models

# Register your models here.

admin.site.register(models.Profile)
admin.site.register(models.CannabisSmoke)
admin.site.register(models.Religion)
admin.site.register(models.Hobbies)
admin.site.register(models.Education)
